JAVA_OPTS="$JAVA_OPTS -Xms4G -Xmx4G -Djavax.net.ssl.trustStore=$JAVA_HOME/jre/lib/security/jssecacerts"
