#!/usr/bin/env bash

if [ ! -d "/opt/data" ]; then
  mkdir /opt/data

  echo copy data
  cp -r geoserver /opt/data
  cp -r postgres /opt/data
else 
  echo Directory /opt/data already exist. Data not be rewrited.
fi

