JAVA_OPTS="$JAVA_OPTS  -Xms24G -Xmx24G -Djavax.net.ssl.trustStore=$JAVA_HOME/jre/lib/security/jssecacerts"
